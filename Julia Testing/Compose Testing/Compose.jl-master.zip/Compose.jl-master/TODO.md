
* Coherent hstack and vstack functions.
* Documentation!!!
* Functions for arranging canvases in, e.g. grids.
* Embedding fonts in SVGs.

